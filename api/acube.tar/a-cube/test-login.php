<?php
require __DIR__ . '/src/TokenProvider.php';
$config = require __DIR__ . '/config.php';

$tp = new TokenProvider($config);
try {
    $header = $tp->getAuthHeader();
    echo "OK, header: " . $header . PHP_EOL;
} catch (Exception $e) {
    echo "FAIL: " . $e->getMessage() . PHP_EOL;
}

